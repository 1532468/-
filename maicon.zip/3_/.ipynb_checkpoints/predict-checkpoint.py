"""
Predict
"""
from datetime import datetime
from tqdm import tqdm
import numpy as np
import random, os, sys, torch, cv2, warnings
from glob import glob
from torch.utils.data import DataLoader

prj_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(prj_dir)

from modules.utils import load_yaml, save_yaml, get_logger
from modules.scalers import get_image_scaler
from modules.datasets import SegDataset
from models.utils import get_model
warnings.filterwarnings('ignore')

if __name__ == '__main__':
    
    # seed_ensemble을 위한 seed list 지정
    model_list = []
    for seed in [10, 20, 30, 40, 50]:
        
        #! Load config
        config_file  = load_yaml(os.path.join(prj_dir, 'config', f'predict{seed}.yaml'))
        
        train_config = load_yaml(os.path.join(prj_dir, 'results', 'train', 
                                              config_file['train_serial'], 'train.yaml'))
        
        #! Set predict serial
        pred_serial = config_file['train_serial'] + '_' + datetime.now().strftime("%Y%m%d_%H%M%S")

        # Set random seed, deterministic
        torch.cuda.manual_seed(seed)
        torch.manual_seed(seed)
        np.random.seed(seed)
        random.seed(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

        # Set device(GPU/CPU)
        os.environ['CUDA_VISIBLE_DEVICES'] = str(config_file['gpu_num'])
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # Load architecture and weight
        model = get_model(model_str=train_config['architecture'])
        model = model(classes=train_config['n_classes'],
                        encoder_name=train_config['encoder'],
                        encoder_weights=train_config['encoder_weight'],
                        activation=train_config['activation']).to(device)

        check_point_path = os.path.join(prj_dir, 'results', 'train',
                                        config_file['train_serial'], 'model.pt')
        check_point = torch.load(check_point_path)
        model.load_state_dict(check_point['model'])

        model_list.append(model)
        
    # Create test result directory
    pred_result_dir = '/workspace/Final_Submission/ensemble/3_result'
    pred_result_dir_mask = '/workspace/Final_Submission/ensemble/3_result/mask'
    os.makedirs(pred_result_dir, exist_ok=True)
    os.makedirs(pred_result_dir_mask, exist_ok=True)
    
    # Set data path
    test_img_paths = glob(os.path.join('/workspace/Final_Submission/data/test/x/*.png'))
                          
    #! Load data & create dataset for train 
    test_dataset = SegDataset(paths=test_img_paths,
                            input_size=[train_config['input_width'], train_config['input_height']],
                            scaler=get_image_scaler(train_config['scaler']),
                            mode='test')

    # Create data loader
    test_dataloader = DataLoader(dataset=test_dataset,
                                batch_size=train_config['batch_size'],
                                num_workers=train_config['num_workers'],
                                shuffle=False,
                                drop_last=False)

    # -------- Ensemble Predict -------- #
    print('Predict Start!!')

    for model in model_list:
        model.eval()

    with torch.no_grad():

        for batch_id, (x, orig_size, filename) in enumerate(tqdm(test_dataloader)):

            x = x.to(device, dtype=torch.float)

            # 리스트에 각 모델별 추론 값 저장
            y_pred_list = [model_list[i](x).argmax(1).squeeze() for i in range(len(model_list))]
            
            # 각 모델별 추론 값을 stack (batch x w x h => model_num x batch x w x h)
            temp = torch.stack(y_pred_list, dim=0)

            # Pixel-wise hard voting 수행, 최종 이미지 추론 
            vote_result, _= torch.mode(temp, dim=0)
            vote_result = vote_result.detach().cpu().numpy()
        
            
            orig_size = [(orig_size[0].tolist()[i], orig_size[1].tolist()[i]) for i in range(len(orig_size[0]))]
            for filename_, orig_size_, y_pred_ in zip(filename, orig_size, vote_result):
                resized_img = cv2.resize(y_pred_, [orig_size_[1], orig_size_[0]], interpolation=cv2.INTER_NEAREST)
                cv2.imwrite(os.path.join(pred_result_dir_mask, filename_), resized_img)
    # logger.info(f"END PREDICTION")