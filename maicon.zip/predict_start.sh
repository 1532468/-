#!/bin/bash

SHELL_PATH=`pwd -P`

echo "========== Predict =========="
echo "Predict 1/5"
python3 $SHELL_PATH/1_/predict.py
echo "Predict 2/5"
python3 $SHELL_PATH/2_/predict.py
echo "Predict 3/5"
python3 $SHELL_PATH/3_/predict.py
echo "Predict 4/5"
python3 $SHELL_PATH/4_/predict.py
echo "Predict 5/5"
python3 $SHELL_PATH/5_/predict.py
echo "ensemble"
python3 $SHELL_PATH/ensemble/ensemble.py
echo "End"