import cv2
import numpy as np
from tqdm import tqdm
from glob import glob
import torch

dev = 'cuda' if torch.cuda.is_available() else 'cpu'

# 앙상블(hard voting)할 마스크들 경로 지정

s1 = '/workspace/Final_Submission/ensemble/3_result/mask/'  # 74
s2 = '/workspace/Final_Submission/ensemble/5_result/mask/'  # 82
s3 = '/workspace/Final_Submission/ensemble/2_result/mask/'  # 73
s4 = '/workspace/Final_Submission/ensemble/1_result/mask/'  # 58
s5 = '/workspace/Final_Submission/ensemble/4_result/mask/'  # 76

for x in tqdm(range(1000,3338)):
    temp = torch.stack([
        torch.from_numpy(cv2.imread(s1 + f'{x}.png', cv2.IMREAD_GRAYSCALE)), 
        torch.from_numpy(cv2.imread(s2 + f'{x}.png', cv2.IMREAD_GRAYSCALE)), 
        torch.from_numpy(cv2.imread(s3 + f'{x}.png', cv2.IMREAD_GRAYSCALE)),
        torch.from_numpy(cv2.imread(s4 + f'{x}.png', cv2.IMREAD_GRAYSCALE)),
        torch.from_numpy(cv2.imread(s5 + f'{x}.png', cv2.IMREAD_GRAYSCALE)),
    ], dim=0).to(dev)

    # hard voting
    vote_result, _= torch.mode(temp, dim=0)
    result = vote_result.detach().cpu().numpy().astype(np.int8)
    
    # save image
    cv2.imwrite(f'/workspace/Final_Submission/submission_image/{x}.png', result)
    torch.cuda.empty_cache()