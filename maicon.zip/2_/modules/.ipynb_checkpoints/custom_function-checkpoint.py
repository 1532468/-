import cv2
import numpy as np
from tqdm import tqdm

def album():
    return

def pre_process(data_path,cond_check, th=0):
    
    # data path : 학습 이미지가 저장된 경로
    # cond_check : pre_process 1/2/3 적용 여부 (boolean type)

    cond1, cond2, cond3 = cond_check

    re= []
    print('이미지 전처리 중')
    for file in tqdm(data_path):
        image = cv2.imread(file, cv2.IMREAD_GRAYSCALE)
        mask = cv2.imread(file.replace('x', 'y'), cv2.IMREAD_GRAYSCALE)
        
        mask1 = mask[ :, :mask.shape[1]//2 ]
        mask2 = mask[ :, mask.shape[1]//2: ]

        if cond1: # cond1 : 이미지와 마스크의 shape이 다른 이미지 학습 제외
            if image.shape != mask.shape:
                continue
        if cond2: # cond2 : 마스크 좌 우 라벨이 겹치는 이미지 학습 제외
            if np.sum(mask1 * mask2) > 0:
                continue
        if cond3: # cond3 : 마스킹된 영역이 너무 작은(mask.size * th) 이미지 학습 제외
            if (np.sum(mask1 > 0) + np.sum(mask2 > 0)) < (mask.size * th):
                continue
        re.append(file)
    
    print(f'이미지 전처리 종료, 학습 이미지 수: {len(re)}')
    return re
