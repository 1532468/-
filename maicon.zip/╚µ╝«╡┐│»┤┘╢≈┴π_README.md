# 국방 AI 경진대회 코드 사용법
- 흑석동날다람쥐 : 박성현, 강주현, 장성욱, 하은택
- 닉네임 : BCODE, ADCC.KJH, swjang, het117
<br><br>

# 핵심 파일 설명
  - 학습 데이터 경로 : `/workspace/Final_Submission/data/train/x`
  - 마스크 경로 : `/workspace/Final_Submission/data/train/y`
  - Network 초기 값으로 사용한 공개된 Pretrained 파라미터<br>
  `baseline에 포함된 segmentation_models_pytorch 라이브러리의 encoder, decoder 모델 조합 사용(ex. resnet_101 + DeepLabv3Plus 등)`
#### 쉬운 재현을 위해 각 모델별 학습/추론 코드가 담긴 Clone Directory 생성
  - 학습 메인 코드: `/workspace/Final_Submission/ + `<br> `1_/train.py, 2_/train.py, 3_/train.py, 4_/train.py, 5_/train.py`<br>
    <font color=#3CB371>&nbsp;＊모델별 학습/테스트 코드 별도 실행 필요(하단 학습 실행 방법 참조)</font>
  - 테스트 메인 코드: `/workspace/Final_Submission/ + `<br> `1_/predict.py, 2_/predict.py, 3_/predict.py, 4_/predict.py, 5_/predict.py`
  - 테스트 이미지 : `/workspace/Final_Submission/data/test/x`
  - 테스트 결과 이미지 경로: `/workspace/Final_Submission/submission_image`
<br><br>

# 코드 구조 설명
 - baseline 기반 일부 수정 후 학습 및 테스트
    - 최종 사용 모델 : sagmentations_models_pytorch에서 제공하는 DeepLapV3+ 모델 + 다양한 encoder 조합 
    - 5개 모델 추론 이미지 생성, 앙상블(hard voting) 수행하여 최종제출 이미지파일 생성
    - 5개 모델별 세부 파라미터 train.yaml 참조
      ```
      /workspace/Final_Submission/1_/config/train.yaml
      /workspace/Final_Submission/2_/config/train.yaml
      /workspace/Final_Submission/3_/config/train.yaml
      /workspace/Final_Submission/4_/config/train.yaml
      /workspace/Final_Submission/5_/config/train.yaml
      ```

  - modules에 custom_function.py 추가
    - Albumentations( ) : 데이터 증강(Augmentation)
    - pre_process( ) : 데이터 전처리
  
    ```
    /workspace/Final_Submission/1_/modules/custom_function.py
    /workspace/Final_Submission/2_/modules/custom_function.py
    /workspace/Final_Submission/3_/modules/custom_function.py
    /workspace/Final_Submission/4_/modules/custom_function.py
    /workspace/Final_Submission/5_/modules/custom_function.py
    ```
  - 1, 4번 모델은 교차검증을 적용한 모델로 train.py 수정
    ```
    /workspace/Final_Submission/1_/train.py (line 136~144)
    /workspace/Final_Submission/4_/train.py (line 136~144)
    ```
  - 3번 모델은 시드 앙상블을 적용한 모델로 train.py 및 predict.py 수정
    ```
    /workspace/Final_Submission/3_/train.py (line 31~32)
    /workspace/Final_Submission/3_/predict.py (line 22~24, 83~109)
    ```
    
  - 5개 모델 추론 결과를 앙상블(Pixelwise hard voting)하는 모듈 추가
    ```
    /workspace/Final_Submission/ensemble/ensemble.py
    ```

- **최종 제출 파일 :** `/workspace/Final_Submission/submission_image/final_result.zip`
- **학습된 가중치 파일**<br>
  **1번 모델:** `/workspace/Final_Submission/1_/results/train/20221112_195340/model.pt`<br>
  **2번 모델:** `/workspace/Final_Submission/2_/results/train/20221113_185542/model.pt`<br>
  **3번 모델(시드 앙상블)<br>**
  &nbsp;&nbsp;&nbsp;1) `/workspace/Final_Submission/3_/results/train/20221113_180246/model.pt`<br>
  &nbsp;&nbsp;&nbsp;2) `/workspace/Final_Submission/3_/results/train/20221113_151637/model.pt`<br>
  &nbsp;&nbsp;&nbsp;3) `/workspace/Final_Submission/3_/results/train/20221113_123118/model.pt`<br>
  &nbsp;&nbsp;&nbsp;4) `/workspace/Final_Submission/3_/results/train/20221113_094624/model.pt`<br>
  &nbsp;&nbsp;&nbsp;5) `/workspace/Final_Submission/3_/results/train/20221113_070144/model.pt`<br>
  **4번 모델:** `/workspace/Final_Submission/4_/results/train/20221113_220243/model.pt`<br>
  **5번 모델:** `/workspace/Final_Submission/5_/results/train/20221114_095209/model.pt`<br>
  
## 주요 설치 library
- /workspace/Final_Submission/environment/conda.txt, pip.txt, environment.yaml 참조
  <br><font color=#3CB371>＊anaconda env에 설치된 리스트를 conda.txt, pip.txt로 리다이렉션하여 저장함
  <br>＊conda env export > environment.yaml 명령어를 실행하여 anaconda에서 사용할 수 있도록 yaml 저장</font><br><br>

# 실행 환경 설정

  - 소스 코드 및 conda 환경 설치
    ```
    cd /workspace/Final_Submission/environment

    conda env create --file environment.yaml
    conda activate MAICON
    ```
<br>

# 학습 실행 방법

  - 학습을 위한 경로 설정
    - `/workspace/Final_Submission` 경로로 이동<br><br>

  - 학습 스크립트 실행
    ```
    ./train_start.sh
    ```
    
  - 학습 스크립트 내용
    ```
    #!/bin/bash

    SHELL_PATH=`pwd -P`

    echo "========== Train =========="
    echo "Train1/5"
    python3 $SHELL_PATH/1_/train.py
    echo "Train2/5"
    python3 $SHELL_PATH/2_/train.py
    echo "Train3/5"
    python3 $SHELL_PATH/3_/train.py
    echo "Train4/5"
    python3 $SHELL_PATH/4_/train.py
    echo "Train5/5"
    python3 $SHELL_PATH/5_/train.py
    echo "End"
    ```
<br>

# 테스트 실행 방법
  
  - 테스트를 위한 설정
    - `/workspace/Final_Submission` 경로로 이동<br><br>
    - 학습 당시 train_serial에 맞춰 5개 디렉토리 내 predict.yaml 파일의 train_serial 값 수정<br> <font color=#3CB371>* 3번 디렉토리의 경우 predict.yaml 파일 5개 필요(파일명: predict10.yaml, predict20.yaml, predict30.yaml, predict40.yaml, predict50.yaml)</font>

  - 테스트 스크립트 실행
    ```
    ./predict_start.sh
    ```

  - 테스트 스크립트 내용
  
    ```
    #!/bin/bash

    SHELL_PATH=`pwd -P`

    echo "========== Predict =========="
    echo "Predict 1/5"
    python3 $SHELL_PATH/1_/predict.py
    echo "Predict 2/5"
    python3 $SHELL_PATH/2_/predict.py
    echo "Predict 3/5"
    python3 $SHELL_PATH/3_/predict.py
    echo "Predict 4/5"
    python3 $SHELL_PATH/4_/predict.py
    echo "Predict 5/5"
    python3 $SHELL_PATH/5_/predict.py
    echo "ensemble"
    python3 $SHELL_PATH/ensemble/ensemble.py
    echo "End"

    # 상기의 5가지(1, 2, 3(seed 앙상블), 4, 5) 추론 결과를 Pixel-wise voting(hard) 처리하여 최종 결과(이미지) 생성
    ```