#!/bin/bash

SHELL_PATH=`pwd -P`

echo "========== Train =========="
echo "Train1/5"
python3 $SHELL_PATH/1_/train.py
echo "Train2/5"
python3 $SHELL_PATH/2_/train.py
echo "Train3/5"
python3 $SHELL_PATH/3_/train.py
echo "Train4/5"
python3 $SHELL_PATH/4_/train.py
echo "Train5/5"
python3 $SHELL_PATH/5_/train.py
echo "End"
